import { render } from "react-dom"

render(<div>sfs </div>, document.getElementById("root"))
