export function someFn(arg: any): string {
  console.log("f")

  return arg
}
